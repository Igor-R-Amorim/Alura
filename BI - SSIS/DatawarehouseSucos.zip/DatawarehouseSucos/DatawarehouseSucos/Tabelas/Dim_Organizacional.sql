﻿CREATE TABLE [dbo].[Dim_Org]
(
	[Cod_Filho] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [Desc_Filho] NVARCHAR(200) NULL, 
    [Cod_Pai] NVARCHAR(50) NULL, 
    [Esquerda] INT NULL, 
    [Direita] INT NULL, 
    [Nivel] INT NULL, 
    CONSTRAINT [FK_Dim_Org_Dim_Org] FOREIGN KEY ([Cod_Pai])
    REFERENCES [Dim_Org]([Cod_Filho])
)
